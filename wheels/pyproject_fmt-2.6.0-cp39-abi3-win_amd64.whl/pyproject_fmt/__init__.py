"""Format pyproject.toml files."""

from __future__ import annotations

from .__main__ import runner as run

__all__ = [
    "run",
]
